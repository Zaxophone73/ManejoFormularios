package com.ttidtech.llenadodeformularios;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Verificacion extends AppCompatActivity {

    private TextView tvNombre;
    private TextView tvNacimiento;
    private TextView tvTelefono;
    private TextView tvEmail;
    private TextView tvInformacion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verificacion);
        Regresar();

        Bundle datos = getIntent().getExtras();
        String nombre = datos.getString("nombre");
        String nacimiento = datos.getString("nacimiento");
        String telefono = datos.getString("telefono");
        String email = datos.getString("email");
        String informacion = datos.getString("informacion");


        tvNombre = (TextView) findViewById(R.id.tvNombre);
        tvNombre.setText(nombre);
        tvNacimiento = (TextView) findViewById(R.id.tvNacimiento);
        tvNacimiento.setText(nacimiento);
        tvTelefono = (TextView) findViewById(R.id.tvTelefono);
        tvTelefono.setText(telefono);
        tvEmail = (TextView) findViewById(R.id.tvEmail);
        tvEmail.setText(email);
        tvInformacion = (TextView) findViewById(R.id.tvInformacion);
        tvInformacion.setText(informacion);

    }
    public void Regresar() {

        Button Retorno = (Button) findViewById(R.id.btnEditar);
        Retorno.setOnClickListener(new View.OnClickListener() {        //hago clic y se abre el 2

            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),Inicial.class);
                onBackPressed();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Log.i("ActionBar", "Atrás");
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
