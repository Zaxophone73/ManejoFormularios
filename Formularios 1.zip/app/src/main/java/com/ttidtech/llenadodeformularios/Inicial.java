package com.ttidtech.llenadodeformularios;

        import android.content.Intent;
        import android.support.v7.app.AppCompatActivity;
        import java.util.Calendar;
        import android.app.DatePickerDialog;
        import android.app.Dialog;
        import android.os.Bundle;
        import android.view.View;
        import android.view.View.OnClickListener;
        import android.widget.Button;
        import android.widget.DatePicker;
        import android.widget.EditText;
        import android.widget.TextView;

public class Inicial extends AppCompatActivity {

    private DatePicker dpResultado;
    private Button btnCambiarFecha;

    EditText etNombre;
    TextView tvNacimiento;
    EditText etTelefono;
    EditText etEmail;
    EditText etInformacion;

    private int año;
    private int mes;
    private int dia;

    static final int DATE_DIALOG_ID = 999;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicial);

        ajustarFechaOnView();
        ajustarFecha();
        Siguiente();

        etNombre = (EditText)findViewById(R.id.etNombre) ;
        tvNacimiento = (TextView) findViewById(R.id.tvNacimiento) ;
        etTelefono = (EditText)findViewById(R.id.etTelefono) ;
        etEmail = (EditText)findViewById(R.id.etEmail) ;
        etInformacion = (EditText)findViewById(R.id.etInformacion) ;
    }

    public void Siguiente() {           // Envia datos e inicia la otra Activity

        Button entry = (Button) findViewById(R.id.btnSiguiente);
        entry.setOnClickListener(new View.OnClickListener() {        //hago clic y se abre el 2

            @Override
            public void onClick(View v) {

                Intent i = new Intent(getApplicationContext(),Verificacion.class);
                String nombre =etNombre.getText().toString();
                String nacimiento =tvNacimiento.getText().toString();
                String telefono =etTelefono.getText().toString();
                String email =etEmail.getText().toString();
                String informacion =etInformacion.getText().toString();
                i.putExtra("nombre",nombre);
                i.putExtra("nacimiento",nacimiento);
                i.putExtra("telefono",telefono);
                i.putExtra("email",email);
                i.putExtra("informacion",informacion);
                startActivity(i);
            }
        });
    }


    public void ajustarFechaOnView() {  //Pondra fecha actual al DatePicker y al TextView

        dpResultado = (DatePicker) findViewById(R.id.dpResultado);

        final Calendar c = Calendar.getInstance();
        int año = c.get(Calendar.YEAR);
        int mes = c.get(Calendar.MONTH);
        int dia = c.get(Calendar.DAY_OF_MONTH);

        dpResultado.init(año, mes,dia, null);

        TextView tvNacimiento =(TextView)findViewById(R.id.tvNacimiento);
        tvNacimiento.setText(new StringBuilder().append(dia).append("/").append(mes + 1).append("/").append(año).append(""));

    }

    public void ajustarFecha() {

        btnCambiarFecha = (Button) findViewById(R.id.btnCambiarFecha);

        btnCambiarFecha.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                // pone los datos del DatePicker en el TextView

                dpResultado = (DatePicker) findViewById(R.id.dpResultado);

                int dia = dpResultado.getDayOfMonth();
                int mes = dpResultado.getMonth();
                int año = dpResultado.getYear();

                tvNacimiento.setText(new StringBuilder().append(dia)
                        .append("/").append(mes + 1).append("/").append(año)
                        .append(" "));

            }

        });

    }

}