package com.ttidtech.llenadodeformularios;

/**
 * Created by Ugalde on 28/09/2017.
 */

public class Contacto {


    private String nombre;
    private String nacimiento;
    private String telefono;
    private String email;
    private String informacion;

    public Contacto(String nombre,String nacimiento, String telefono, String email, String informacion) {
        this.nombre = nombre;
        this.nacimiento = nacimiento;
        this.telefono = telefono;
        this.email = email;
        this.informacion =informacion;

    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNacimiento() {
        return nacimiento;
    }

    public void setNacimiento(String nacimiento) {
        this.nacimiento = nacimiento;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getInformacion() {
        return informacion;
    }

    public void setInformacion(String informacion) {
        this.informacion = informacion;
    }
}
